---
title: PyDiff - Python 结构化程序比较工具
tags: 转摘, ydiff
categories: 
date: 2016-03-17 19:04:36
---


在之前的一篇博文里，我介绍了 [ydiff](http://www.yinwang.org/blog-cn/2013/04/21/ydiff-%E7%BB%93%E6%9E%84%E5%8C%96%E7%9A%84%E7%A8%8B%E5%BA%8F%E6%AF%94%E8%BE%83/)，一个通用的结构化程序比较工具。其实在设计 ydiff 之前，这个工具是用 Python 实现的，并且只处理 Python 程序。在设计了 ydiff 之后，我发现其实我不想费很多精力来写 Python 的 parser，所以对 Python 的支持就日渐疏忽了。后来我把那块代码放在了 ydiff 的 repo 里面（叫做 pydiff.py），然而几乎没有人注意到它。

<!--more-->

现在我发现 Python 其实是一个挺重要而且有趣的语言。说它重要是因为它简单而且在某种程度上是优雅的，所以有很多人用它。说它有趣是因为它的一些设计其实比起很多更加“严谨”的语言要来得合理。语言的设计不只要有逻辑的严谨和效率，而且需要有“易用性”（usability）。Python 在易用性上面是做的比较好的。最近仔细看了一下 [PEP 8](http://www.python.org/dev/peps/pep-0008/) (Python 的 "Style Guide"），发现它有很多地方比起 Java, Scheme, Haskell 都有让程序更加“易读”的特点。

所以，现在我为这个 Python 的结构化比较程序重新建立了它自己的 GitHub 项目。你可以在这里得到它的代码： [https://github.com/yinwang0/pydiff](http://github.com/yinwang0/pydiff)

对比大型文件的时候可能速度会成一定的问题。不过我打算以后对算法做一个比较大的改进。如果发现 bug 请在 GitHub 中向我报告。谢谢。

### Demo

你可以在下面的窗口中看到 PyDiff 的输出结果，是 PyDiff 对比它自己的代码（我最近两天对它的修改）。

<iframe width="100%" height="540" src="http://www.yinwang.org/resources/pydiff1-pydiff2.html"></iframe>
([单独浏览](http://www.yinwang.org/resources/pydiff1-pydiff2.html))


上面的界面有如下特点：

1.	红色表示“删除”，绿色表示“插入”，白色表示“移动”或者没有变化，蓝色表示有小幅度“修改”。
2.	左右窗口同步滚动。
3.	点击白色方框，就可以依据框里的变量进行对齐。
4.	点击之后，左右窗口根据对齐的变量重新“耦合”，同步滚动。