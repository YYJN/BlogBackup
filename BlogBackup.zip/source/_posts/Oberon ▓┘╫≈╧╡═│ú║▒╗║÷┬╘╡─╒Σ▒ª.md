---
title: Oberon 操作系统：被忽略的珍宝
tags: 转摘
categories: 
date: 2016-03-15 19:02:47
---

# Oberon 操作系统：被忽略的珍宝

推荐一篇很久以前看的文章：[Oberon - The Overlooked Jewel](http://www.ics.uci.edu/~franz/Site/pubs-pdf/BC03.pdf)
<!--more-->

它介绍的是 Niklaus Wirth 设计的一种操作系统，叫做 Oberon。Niklaus Wirth 就是大家熟知的 Pascal 语言的设计者。绝大部分人都没听说过有 Oberon 这个东西存在，更难以把它跟 Niklaus Wirth 的大名挂上钩。所以作者说：“Wirth 因为 Pascal 而闻名于世，可是接下来几年，他成为了 Pascal 的受害者。” 确实是这样。Wirth 一直都不觉得 Pascal 是他的杰作。我想他应该会更喜欢以 Oberon 闻名于世。

Oberon 比起 Unix，有很大的不同，在于它的数据都是结构化的。进程间不通过字符串交换数据，而是直接使用数据结构。很奇特的一点是，Oberon 操作系统是用一种同名的程序语言（Oberon 语言）写成。令人惊讶的是，在那个年代，ETH 计算机系的所有教职员工，学生，包括办公室的大妈，都是用的这种操作系统。

操作系统的设计，真是天外有天。